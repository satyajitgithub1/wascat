<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<style type="text/css">
  /*.form-group {
      margin-bottom: 15px;
  }*/
  .btn-bs-file{
      position:relative;
  }
  .btn-bs-file input[type="file"]{
      position: absolute;
      top: -9999999;
      filter: alpha(opacity=0);
      opacity: 0;
      width:0;
      height:0;
      outline: none;
      cursor: inherit;
  }
  .profile-user-img {
    margin: 0 auto;
    width: 150px;
    padding: 1px;
  }
</style>

<div class="content-wrapper">
  <section class="content-header">
    <h1>
     <?php echo e(Session :: get('meg')); ?>

    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">UI</a></li>
      <li class="active">General</li>
    </ol>
  </section>
  <section class="content">
   
    <div class="row">
      <div class="col-md-12">
        <div class="nav-tabs-custom">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_1" data-toggle="tab">List</a></li>
            <li class=""><a href="#tab_2" data-toggle="tab">Add new</a></li>
          </ul>

          <div class="tab-content">
            <div class="tab-pane active" id="tab_1">
              <div class="box">
                <div class="box-header">
                 <h3 class="box-title">AVAILABLE VARIOUS TYPE OF ITEM </h3>
                </div>
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>SERIAL NO</th>
                        <th>TYPE OF ITEM</th>
                        <th>IMAGE</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $sl=0;?>
                      <?php $__currentLoopData = $all_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e(++$sl); ?></td>
                        <td><?php echo e($info->name); ?></td>
                        <td style="text-align: center; height: 80px;width:100px;"><img class="profile-user-img img-responsive img-thumbnail" src="<?php echo e(isset($info->image) && $info->image != '' ? asset('public/upload/' . $info->image) : asset('upload/default-avatar.png')); ?>" alt="User profile picture"></td>
                        
                        <td>
                         <a href="<?php echo e(url('/item_type/delete/'.$info->id)); ?>" class="" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                         <a href="<?php echo e(url('/item_type/edit/'.$info->id)); ?>" class="" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td> 
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
                  </table>
                  <?php echo e($all_info->links()); ?>

                </div>
              </div>
            </div>

            <div class="tab-pane" id="tab_2">
              <?php echo Form::open(['url' => 'item_type/save','class'=>'form-horizontal','id'=>'contact-form','method'=>'post','enctype'=>'multipart/form-data']); ?>

              
                <div class="box box-info">
                  <div class="box-body">

                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label for="itemtype" class="col-sm-4 control-label">TYPE OF ITEM</label>
                          <div class="col-sm-8">
                           <input type="text" class="form-control" name="itemtype" id="iteamtype" placeholder="type of item name">
                          </div>
                        </div>

                        <table style="width: 100%;">
                          <tr><td style="text-align: center; height: 150px;"><img class="profile-user-img img-responsive img-thumbnail" src="" alt="User signature picture" id="previewProfileImage_sing"></td></tr>
                          <tr><td><h3 class="profile-username text-center">Signature</h3></td></tr>
                          <tr><td style="text-align: center;">
                            <label class="btn-bs-file btn btn-primary btn-block" style="width: 160px; margin: auto;">
                                Select Signature
                                <input type="file" name="signature" id="image_select_btn_sing" />
                            </label>
                          </td></tr>
                        </table>
                        <br>


                       <center>
                         <button type="submit" name="submit" value="submit" class="btn btn-success btn-flat">Add</button>
                       </center>
                    </div>
                    <div class="col-md-4"></div>
                  </div>
                </div>
              <?php echo Form::close(); ?>

            </div>
          </div>
        </div>
      </div>
    </div>  
  </section>
</div>
<script>
      $("#image_select_btn_sing").change(function(){
          var fuData = document.getElementById('image_select_btn_sing');
          var fsize = fuData.files[0].size / 1024;
          if ((fsize/1024) > 2) {
            $("#idproof_upl").val('');
            alert("File size not more than 2 MB.");
            return;
          }
          var FileUploadPath = $("#image_select_btn_sing").val();
          if (FileUploadPath == '') {
              $("#previewProfileImage_sing").attr('src', defaultImage1);
          } 
          else 
          {
              var Extension = FileUploadPath.substring(FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
              if (Extension == "png" || Extension == "jpeg" || Extension == "jpg") {
                  var setURL = window.URL || window.webkitURL;
                  var imageFile = this.files[0];
                  var imageFileObject = new Image();
                  imageFileObject.src = setURL.createObjectURL(imageFile);
                  imageFileObject.onload = function(){
                      var imgWidth = this.width;
                      var imgHeight = this.height;
                      // if (imgWidth > 230 || imgHeight > 200) {
                      //     alert('Signature resolution is too high')
                      //     $("#image_select_btn_sing").val('');
                      // }
                      // else{
                          $("#previewProfileImage_sing").attr('src', setURL.createObjectURL(imageFile));
                          $("#previewProfileImage_sing").css({height:"150px", width:"150px"});
                      //}
                  }
              }
              else 
              {
                $("#image_select_btn_sing").val('');
                  alert("Photo only allows file types of PNG, JPG and JPEG. ");
              }
          }
      });
  </script>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>