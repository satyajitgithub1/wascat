<?php echo $__env->make('layouts.admin_component.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php echo $__env->make('layouts.admin_component.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
   <?php echo $__env->make('layouts.admin_component.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.admin_component.footer_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;


   <?php echo $__env->yieldContent('content'); ?>
   
   

<?php echo $__env->make('layouts.admin_component.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
   
  <div class="control-sidebar-bg"></div>
</div>

<!-- ./wrapper -->


 </body>
</html>
