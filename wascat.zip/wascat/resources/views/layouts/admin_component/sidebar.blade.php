 <aside class="main-sidebar">
        <section class="sidebar">

          <div class="user-panel">
            <div class="pull-left image">
             <img src="{{asset('public/admin')}}/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p>SUKUMAR BERA</p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>

         

          <ul class="sidebar-menu" data-widget="tree">

         <li>
          <a href="#"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
        </li>

          <li class="treeview">
            <a href="#">
              <i class="fa fa-plus"></i> <span>MASTER</span>
              <span class="pull-right-container">
               <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="{{ url('/item_type') }}"><i class="fa fa-circle-o"></i> ITEM TYPE</a></li>
              <li><a href="unit.php"><i class="fa fa-circle-o"></i> UNIT</a></li>
              <li><a href="pdetails.php"><i class="fa fa-circle-o"></i> PERSON DETAILS</a></li>
            </ul>
          </li>


          <li class="treeview active">
            <a href="#">
              <i class="fa fa-plus"></i>
              <span>TRANSACTION</span>
              <span class="pull-right-container">
               <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="stock.php"><i class="fa fa-circle-o"></i> STOCK IN</a></li>
              <li><a href="sale.php"><i class="fa fa-circle-o"></i> SALES</a></li>
            </ul>
          </li>

         

        </section>
  </aside>