@include('layouts.admin_component.header')
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  @include('layouts.admin_component.head')
 
   @include('layouts.admin_component.sidebar')
@include('layouts.admin_component.footer_js');


   @yield('content')
   
   

@include('layouts.admin_component.footer');
   
  <div class="control-sidebar-bg"></div>
</div>

<!-- ./wrapper -->


 </body>
</html>
