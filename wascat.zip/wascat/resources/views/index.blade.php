@extends('layouts._admin')

@section('content')
  <!-- Content Wrapper. Contains page content -->


  <div class="content-wrapper">
        <section class="content-header">
          <h1>
           It is well come page
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">UI</a></li>
            <li class="active">General</li>
          </ol>
        </section>
      </div>
 <!--<div class="content-wrapper">
        <section class="content-header">
          <h1>
            MASTER
            <small>PREVIEW OF VARIOUS TYPE OF ITEM</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">UI</a></li>
            <li class="active">General</li>
          </ol>
        </section>
        <section class="content">
         
          <div class="row">
            <div class="col-md-12">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tab_1" data-toggle="tab">List</a></li>
                  <li class=""><a href="#tab_2" data-toggle="tab">Add new</a></li>
                </ul>

                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                    <div class="box">
                      <div class="box-header">
                       <h3 class="box-title">AVAILABLE VARIOUS TYPE OF ITEM</h3>
                      </div>
                      <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                          <thead>
                            <tr>
                              <th>SERIAL NO</th>
                              <th>TYPE OF ITEM</th>
                            </tr>
                          </thead>
                          <tbody>
                             
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>

                  <div class="tab-pane" id="tab_2">
                    <form action="../controller/item.php" class="form-horizontal" method="post" id="contact-form" role="form">
                      <div class="box box-info">
                        <div class="box-body">

                          <div class="row">
                            <div class="col-md-8">
                              <div class="form-group">
                                <label for="itemtype" class="col-sm-4 control-label">TYPE OF ITEM</label>
                                <div class="col-sm-8">
                                 <input type="text" class="form-control" name="itemtype" id="iteamtype" placeholder="type of item name">
                                </div>
                              </div>
                             <center>
                               <button type="submit" name="submit" value="submit" class="btn btn-success btn-flat">Add</button>
                             </center>
                          </div>
                          <div class="col-md-4"></div>
                        </div>
                      </div>
                    </form>  
                  </div>
                </div>
              </div>
            </div>
          </div>  
        </section>
      </div>!-->
@endsection